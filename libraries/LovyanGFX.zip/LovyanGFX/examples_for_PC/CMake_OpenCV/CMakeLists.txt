cmake_minimum_required (VERSION 3.8)
project(LGFXOpenCV)

add_definitions(-DLGFX_OPENCV)

add_compile_options("$<$<C_COMPILER_ID:MSVC>:/utf-8>")
add_compile_options("$<$<CXX_COMPILER_ID:MSVC>:/utf-8>")
add_compile_options("$<$<CXX_COMPILER_ID:MSVC>:/Zc:__cplusplus>")

# ビルド対象にするファイルを指定する;
# LovyanGFXのあるパスと位置関係を変えた場合は相対パス記述を環境に合わせて調整すること;
file(GLOB Target_Files RELATIVE ${CMAKE_CURRENT_SOURCE_DIR} CONFIGURE_DEPENDS 
    *.cpp
    ../../../LovyanGFX/src/lgfx/Fonts/efont/*.c
    ../../../LovyanGFX/src/lgfx/Fonts/IPA/*.c
    ../../../LovyanGFX/src/lgfx/Fonts/lvgl/*.c
    ../../../LovyanGFX/src/lgfx/utility/*.c
    ../../../LovyanGFX/src/lgfx/v1/*.cpp
    ../../../LovyanGFX/src/lgfx/v1/panel/*.cpp
    ../../../LovyanGFX/src/lgfx/v1/touch/*.cpp
    ../../../LovyanGFX/src/lgfx/v1/lv_font/*.c
    )
add_executable (LGFXOpenCV ${Target_Files})

# includeするファイルのパスを指定する;
# LovyanGFXのあるパスと位置関係を変えた場合は相対パス記述を環境に合わせて調整すること;
target_include_directories(LGFXOpenCV PUBLIC "../../../LovyanGFX/src")

# OpenCVを配置したパス内のincludeのパスを指定する;
target_include_directories(LGFXOpenCV PUBLIC "C:/opencv/build/include")

# OpenCVを配置したパス内の.libファイルのパスを指定する;
target_link_libraries(LGFXOpenCV PUBLIC "C:/opencv/build/x64/vc15/lib/opencv_world452d.lib" )

target_compile_features(LGFXOpenCV PUBLIC cxx_std_17)
